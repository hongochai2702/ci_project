<?php
$lang['error_csrf'] = 'Có lỗi xảy ra trong quá trình đăng nhập.';
?>