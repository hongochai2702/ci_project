<?php
// Heading
$_['heading_title']  = 'Không tìm thấy trang!';

// Text
$_['text_not_found'] = 'Trang bạn đang tìm không tìm thấy được! Xin vui lòng liên hệ với quản trị viên của bạn nếu vấn đề vẫn tồn tại.';
?>
