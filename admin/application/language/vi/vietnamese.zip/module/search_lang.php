<?php
$lang['heading_title'] = 'Tìm kiếm';

?>